<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <style>
        .clientsDrop {
            display: none;
        }

        .showClient {
            display: inline-block !important;
            width: 65%;
        }
        .hidded{
            display: none;
        }

    </style>

    <div class="row">
        <div class="col-lg-12 col-sm-12">
            <div class="card m-b-30">
                <div class="card-body table-responsive">
                    <div class="buttonNav">
                        <h3>Complete Project</h3>
                        <a href="" class="btn btn-info btn-lg" data-toggle="modal" data-animation="bounce"
                            data-target=".bs-example-modal-lg">Add New</a>
                    </div>
                    <div class="">
                        <table id="datatable2" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>SL No</th>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>Work Scope</th>
                                    <th>Company Type Scope</th>
                                    <th>Project Type</th>
                                    <th>Project Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $comProject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kye => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($kye + 1); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><img id="image" src="<?php echo e(URL::to($item->image)); ?>"
                                            style="height: 80px; width: 80px;"></td>
                                        <td><?php echo e($item->workscope); ?></td>
                                        <td><?php echo e($item->companytype); ?></td>
                                        <td>
                                            <?php if($item->projecttype == 'IP'): ?>
                                            Industry Projects
                                            <?php elseif($item->projecttype == 'BFP'): ?>
                                            Bank & Financial Projects
                                                <?php elseif($item->projecttype == 'NP'): ?>
                                                NGO
                                                <?php elseif($item->projecttype == 'CP'): ?>
                                                Club
                                                <?php elseif($item->projecttype == 'HRP'): ?>
                                                Hotel & Resorts
                                                <?php elseif($item->projecttype == 'GVP'): ?>
                                                Govt. Projects
                                                <?php elseif($item->projecttype == 'CBP'): ?>
                                                Commercial Building Projects
                                            <?php else: ?>
                                               Nothing
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($item->status == 1): ?>
                                            Ongoing
                                            <?php elseif($item->status == 0): ?>
                                            Compleate
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href=""
                                                class="delet btn btn-danger mr-2">Delet</a>
                                            <a href=""
                                                class="edit btn btn-info">Edit</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--end row-->

    <!--  Modal content for the above example -->
    <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="myLargeModalLabel">Add News</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card m-b-30">
                                <div class="card-body">

                                    <form class="" action="<?php echo e(route('admin.addCompletedProject')); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group hidded">
                                            <input type="hidden" name="status" value="0" />
                                        </div>
                                        <div class="form-group">
                                            <label>Project Name</label>
                                            <input type="text" name="name" class="form-control"
                                                placeholder="Project Name" required/>
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-500 mt-2 text-sm"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label>Project Image</label>
                                            <div>
                                                <input type="file" name="image" class="form-control" />
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Work Scope</label>
                                            <input type="text" name="workscope" class="form-control"
                                                placeholder="Work Scope" />
                                                <?php $__errorArgs = ['workscope'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-500 mt-2 text-sm"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Project Type</label>
                                            <input type="text" name="companytype" class="form-control"
                                                placeholder="Project Type" required/>
                                                <?php $__errorArgs = ['companytype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-500 mt-2 text-sm"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Project Details</label>
                                            <input type="text" name="projectdetails" class="form-control"
                                                placeholder="Project Details" />
                                                <?php $__errorArgs = ['projectdetails'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-500 mt-2 text-sm"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Project Location</label>
                                            <input type="text" name="Location" class="form-control"
                                                placeholder="Project Location" />
                                                <?php $__errorArgs = ['Location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-500 mt-2 text-sm"><?php echo e($message); ?></p>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label >Project Status</label>
                                            <div >
                                                <select class="form-control" name="projecttype" required>
                                                    <option value="IP">Industry Projects</option>
                                                    <option value="BFP">Bank & Financial Projects</option>
                                                    <option value="NP">NGO</option>
                                                    <option value="CP">Club</option>
                                                    <option value="HRP">Hotel & Resorts</option>
                                                    <option value="GVP">Govt. Projects</option>
                                                    <option value="CBP">Commercial Building Projects</option>
                                                    
                                                </select>
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <div><button type="submit"
                                                    class="btn btn-primary waves-effect waves-light">Submit</button>
                                                <button type="reset" data-dismiss="modal"
                                                    class="btn btn-secondary waves-effect m-l-5">Cancel</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    <!-- /.modal -->

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH E:\Xampp\htdocs\technoapogeeLaravel\resources\views/Backend/completeProject.blade.php ENDPATH**/ ?>