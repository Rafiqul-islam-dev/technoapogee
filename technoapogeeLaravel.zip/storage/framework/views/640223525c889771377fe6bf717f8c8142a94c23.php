
<?php $__currentLoopData = $Project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('title'); ?> <?php echo e($item->name); ?> <?php $__env->stopSection(); ?> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startSection('content'); ?>

<style>
.portfolio-single img{
    width: 100%;
    height: 400px;
}

</style>
       <!-- Breadcrumbs Start -->
       <div class="rs-breadcrumbs">
        <div class="container">
            <div class="breadcrumbs-inner">
                <?php $__currentLoopData = $Project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h1 class="page-title">
                    <?php echo e($item->name); ?>

                </h1>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

            </div>
        </div>
    </div>
    <!-- Breadcrumbs End -->
            <!-- Project Section Start -->
            <div class="rs-project pb-110 md-pt-70 md-pb-7 mt-5">
                <div class="container">
                    <div class="row">                        
                        <div class="col-lg-8 pr-60 md-pr-15">
                            <div class="sec-title mb-64">
                                <?php $__currentLoopData = $Project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h2 class="title title4 pb-30">
                                    About Project
                                </h2>
                                
                                <div class="slider-img portfolio-single">
                                      <img src="<?php echo e(URL::to($item->image)); ?>" alt="Slider">
                                </div>
                                <p class="margin-0 mt-5"><?php echo e($item->projectdetails); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                           
                        </div>
                        <div class="col-lg-4">
                            <div class="project-information bg24">
                                <?php $__currentLoopData = $Project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="sec-title">
                                    <h2 class="title title4 pb-30">
                                        Project information
                                    </h2>
                                    <div class="title-inner mb-25">
                                        <h4 class="title-small">Project Name</h4>
                                        <p class="margin-0"><?php echo e($item->name); ?></p>
                                    </div>
                                    <div class="title-inner mb-25">
                                        <h4 class="title-small">Scope</h4>
                                        <p class="margin-0"><?php echo e($item->workscope); ?></p>
                                    </div>
                                    <div class="title-inner mb-25">
                                        <h4 class="title-small">Project Type</h4>
                                        <p class="margin-0"><?php echo e($item->companytype); ?></p>
                                    </div>
                                    <div class="title-inner mb-25">
                                        <h4 class="title-small">Location</h4>
                                        <p class="margin-0"><?php echo e($item->Location); ?></p>
                                    </div>
                                    
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Project Section End -->

        </div> 
        <!-- Main content End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('fontend.layout.masterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\technoapogeeLaravel\resources\views/fontend/projectDetails.blade.php ENDPATH**/ ?>