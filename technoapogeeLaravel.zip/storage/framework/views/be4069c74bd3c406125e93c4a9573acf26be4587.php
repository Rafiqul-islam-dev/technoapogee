<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card m-b-30">
                <div class="card-body">

                    <form class="" action="<?php echo e(route('admin.updateMenu', $menu->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control"
                                value="<?php echo e($menu->name); ?>"/>
                        </div>
                        <div class="row form-group">
                            <div class="col-lg-6">
                                <label>Image</label>
                                <input type="file" class="form-control" name="image" accept="image/*"
                                    onchange="readURL(this);">
                            </div>
                            <div class="col-lg-6">
                                <img id="image" src="<?php echo e(URL::to($menu->image)); ?>"
                                    style="height: 80px; width: 80px;">
                                <input type="hidden" name="image" value="<?php echo e($menu->image); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <textarea name="description" id="summernote"><?php echo e($menu->description); ?></textarea>
                            
                        </div>
                        <div class="form-group">
                            <label>Parent Id</label>
                            <input type="text" name="parentid" class="form-control"
                            value="<?php echo e($menu->parentid); ?>"/>
                        </div>
                        <div class="form-group">
                            <label>Sub Menu Id</label>
                            <input type="text" name="submenu_id" class="form-control"
                            value="<?php echo e($menu->submenu_id); ?>"/>
                        </div>
                        
                        <div class="form-group">
                            <div><button type="submit"
                                    class="btn btn-primary waves-effect waves-light">Submit</button>
                                <button type="reset"
                                    class="btn btn-secondary waves-effect m-l-5">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<!--end row-->
<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image')
                    .attr('src', e.target.result)
                    .width(226)
                    .height(100);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH E:\Xampp\htdocs\technoapogeeLaravel\resources\views/backend/editMenu.blade.php ENDPATH**/ ?>