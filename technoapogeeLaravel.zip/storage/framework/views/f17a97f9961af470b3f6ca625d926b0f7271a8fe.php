
<?php $__env->startSection('content'); ?>

<style>
    .prodectDetail_img img{
        width: 100%;
        height: 450px;
    }
</style>

<!-- Breadcrumbs Start -->
<div class="rs-breadcrumbs img6">
    <div class="container">
        <div class="breadcrumbs-inner">
            <h1 class="page-title">
                Design & Consultancy Service
            </h1>                       
        </div>
    </div>
</div>
<!-- Breadcrumbs End -->

<!-- Services Section Start -->
<div class="rs-services style2 rs-services-style2 gray-bg pt-100 md-pt-70 md-pb-70">
    <div class="container custom">
        <div class="row">

            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($item->id ==2): ?>
                   
               
            <div class="col-lg-12 col-md-6 mb-20">
                <div class="service-wrap">
                <div class="image-part prodectDetail_img">
                    <img src="<?php echo e(asset($item->image)); ?>" alt="">
                </div>
                    <p><?php echo $item->description; ?></p>
                </div>
             </div>
             <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </div>
    </div>
</div>
<!-- Services Section End -->

<!-- Services Section Start -->
<div class="rs-services style2 rs-services-style2 gray-bg pb-100 md-pt-70 md-pb-70">
    <div class="container custom">
        <div class="row">

            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($item->parentid ==2): ?>
                   
               
            <div class="col-lg-4 col-md-6 mb-20">
                <div class="service-wrap">
                    <div class="image-part">
                        <img src="<?php echo e(asset($item->image)); ?>" alt="">
                    </div>
                    <div class="content-part">
                        
                        <div class="desc"><a href="<?php echo e(url( $item->slug)); ?>"><?php echo e($item->name); ?></a></div>
                    </div>
                </div>
             </div>
             <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </div>
    </div>
</div>
<!-- Services Section End -->

</div> 
<!-- Main content End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('fontend.layout.masterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\technoapogeeLaravel\resources\views/fontend/designConsultancy.blade.php ENDPATH**/ ?>