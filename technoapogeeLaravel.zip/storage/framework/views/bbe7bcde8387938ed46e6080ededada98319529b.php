   
   
   <?php $__env->startSection('title', 'Fire Panel Repair & Maintenance BD - Techno Apogee'); ?>
   <?php $__env->startSection('content'); ?>

       <!-- Breadcrumbs Start -->
       <div class="rs-breadcrumbs img6">
        <div class="container">
            <div class="breadcrumbs-inner">
                <h1 class="page-title">
                    Bank & Financial Projects
                </h1>
            </div>
        </div>
    </div>
    <!-- Breadcrumbs End -->
   <!-- Project Section Start -->
           <div class="rs-project style3 pt-100 pb-100 md-pt-70 md-pb-70">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $indProject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <div class="col-lg-4 col-md-6 mb-30">
                        <a href="">
                            <div class="project-item">
                                <div class="project-img">
                                    <a href="<?php echo e(route('portfolio',  $item->slug_name)); ?>"><img src="<?php echo e(URL::to($item->image)); ?>" alt="images"></a>
                                </div>
                                <div class="project-content">
                                    <div class="portfolio-inner">                                         
                                                                               
                                        <h3 class="title"><a href="<?php echo e(route('portfolio',  $item->slug_name)); ?>"><?php echo e($item->name); ?></a></h3>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <!-- Project Section End -->
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('fontend.layout.masterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\technoapogeeLaravel\resources\views/fontend/bankProjects.blade.php ENDPATH**/ ?>